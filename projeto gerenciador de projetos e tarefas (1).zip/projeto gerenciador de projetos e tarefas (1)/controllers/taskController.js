const Task = require('../models/Task');


exports.createTask = async (req, res) => {
try {
const task = await Task.create(req.body);
res.status(201).json(task);
} catch (err) {
res.status(400).json({ error: err.message });
}
};


exports.getTasks = async (req, res) => {
try {
// permite filtrar por project ou assignee
const filter = {};
if (req.query.project) filter.project = req.query.project;
if (req.query.assignee) filter.assignee = req.query.assignee;
const tasks = await Task.find(filter).populate('project assignee');
res.json(tasks);
} catch (err) {
res.status(500).json({ error: err.message });
}
};


exports.getTaskById = async (req, res) => {
try {
const task = await Task.findById(req.params.id).populate('project assignee');
if (!task) return res.status(404).json({ error: 'Tarefa não encontrada' });
res.json(task);
} catch (err) {
res.status(500).json({ error: err.message });
}
};


exports.updateTask = async (req, res) => {
try {
const task = await Task.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
if (!task) return res.status(404).json({ error: 'Tarefa não encontrada' });
res.json(task);
} catch (err) {
res.status(400).json({ error: err.message });
}
};


exports.deleteTask = async (req, res) => {
try {
const task = await Task.findByIdAndDelete(req.params.id);
if (!task) return res.status(404).json({ error: 'Tarefa não encontrada' });
res.json({ message: 'Tarefa removida' });
} catch (err) {
res.status(500).json({ error: err.message });
}
};
